/* global QUnit */

sap.ui.require(["br/com/embraer/avisodeferias/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
